class ExportTarget:
    def __init__(self, url: str, grupo: str):
        self.url = url
        self.grupo = grupo
